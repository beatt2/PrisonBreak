﻿using UnityEngine;
using UnityEngine.UI;

namespace Player
{
    public class Attack : MonoBehaviour
    {
        public Slider PowerUpSlider;

        private float _highestPoint;

        private Rigidbody _rigidbody;

        private bool go;

        private void Awake()
        {
            _rigidbody = GetComponent<Rigidbody>();
            PowerUpSlider.gameObject.SetActive(false);
        }

        private void Update()
        {
            PowerUpSlider.value = Input.GetAxis("Jump");
            if (Input.GetAxis("Jump") < 0.01f && go)
            {
                go = false;
                PowerUpSlider.gameObject.SetActive(false);
            }

            if (Input.GetButtonDown("Jump"))
            {
                PowerUpSlider.gameObject.SetActive(true);
            }

            if (!Input.GetButtonUp("Jump")) return;
            go = true;
        }

        private void FixedUpdate()
        {
            if (go)
                _rigidbody.AddRelativeForce(Input.GetAxis("Jump") * 5000, 0, 0);


        }
    }
}