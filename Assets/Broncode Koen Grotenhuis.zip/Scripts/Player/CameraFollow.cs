﻿using UnityEngine;
using UnityEngine.Networking;

namespace Player
{
    public class CameraFollow : MonoBehaviour
    {
        public GameObject Player;

        private Vector3 _playerPosition;
        private Vector3 _playerRotation;

        private float _yPosition;
        private float _zPosition;

        private float _yRotation;
        private float _xRotation;

        private void Awake()
        {
            InitPlayerLocation();
            _playerRotation = transform.eulerAngles;
            _xRotation = _playerRotation.x;
        }

        private void InitPlayerLocation()
        {
            _yPosition = transform.position.y;
            _zPosition = transform.position.z;
            //TODO 
            _yRotation = transform.rotation.eulerAngles.y;
            _xRotation = transform.rotation.eulerAngles.x; 
        }

        private void FixedUpdate()
        {

            transform.eulerAngles = new Vector3(_xRotation,transform.eulerAngles.y,0);
        }
    }
}
