﻿using System.ComponentModel;
using AI;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Player
{
    public class PlayerController : MonoBehaviour
    {

        public float WalkSpeed;
        public float TurnSpeed;

        public float BoostTime;
        public float BoostSpeed;

        private Rigidbody _rigidbody;

        private float _health = 1;

        public float Health
        {
            get { return _health; }
            set
            {

                _health = value;
                HealthSlider.value = _health;
                if (_health <= 0)
                {
                    Die();
                }
            }
        }

        public Slider HealthSlider;

        


        private void Awake()
        {
            _rigidbody = GetComponent<Rigidbody>();
        }


        private void FixedUpdate()
        {
            transform.Translate(Input.GetAxis("Vertical") * WalkSpeed,0,0) ;
            float horizon = Input.GetAxis("Horizontal") * TurnSpeed;
            transform.Rotate(0, horizon, 0);



        }

        private void Die()
        {
            EffectManager.Instance.InstansiateExplosion(transform);
            Invoke("LoadScene", 1);
           
        }

        private void LoadScene()
        {
            SceneManager.LoadScene("Main");
            Destroy(gameObject);
        }
    

        private void OnCollisionEnter(Collision other)
        {
            var behaviour = other.gameObject.GetComponent<IGuardBehaviour>();
            if (behaviour?.GetEnum() == GuardManager.GuardState.Triggerd)
            {
                Health -= behaviour.GetDamage();
            }
        }
    }
}
