﻿using System.Collections;
using System.Collections.Generic;
using Door;
using UnityEngine;

public class IDretriever : MonoBehaviour
{
    public Doors.AccessRuleEnum type;



    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<IDoorBehaviour>() != null)
        {

           DoorManager.Instance.OpenDoor(other.gameObject.GetComponent<IDoorBehaviour>().ID(), type);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.GetComponent<IDoorBehaviour>() != null)
        {
            DoorManager.Instance.CloseDoorTrigger(other.gameObject.GetComponent<Doors>(), type);
        }
    }


}
