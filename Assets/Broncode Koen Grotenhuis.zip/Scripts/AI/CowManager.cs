﻿using System.Collections;
using System.Collections.Generic;
using AI;
using UnityEngine;

public class CowManager : AIManagement<CowAI,CowManager.CowLocationEnum,CowManager>
{

    private List<CowAI> _readyCows = new List<CowAI>();

    public GameObject Cow;
    public GameObject CowPoint;
    public Transform[] SpawnLocations;
    public enum CowLocationEnum
    {  
        field
    }

    public void Start()
    {
        for (int i = 0; i < SpawnLocations.Length; i++)
        {
            Instantiate(Cow, SpawnLocations[i].position, Quaternion.identity, CowPoint.transform);
        }
        Invoke("DelayedStart", 5);
    }

    private void DelayedStart()
    {
       SendSomeCowsToPath();
    }

    private void SendSomeCowsToPath()
    {
       StartCoroutine(PatrolTransforms(CowLocationEnum.field, 3, LocationAI.Instance.Field, 20));
    }

    public void CowReachedDestination(CowAI cow)
    {
        _readyCows.Add(cow);
        if (cow.CurrentStage != CowAI.StageEnum.AtButcher) return;
        cow.CurrentStage = CowAI.StageEnum.AtButcher;
        if (_readyCows.Count == 1)
        {
            ButcherCow();
        }
    }

    public void RemoveCow(GameObject go)
    {
        _readyCows.Remove(go.GetComponent<CowAI>());
        RemoveFromList(CowLocationEnum.field, go.GetComponent<CowAI>());

    }

    public void SetAllCowsToButcher()
    {
        StopAllCoroutines();
        foreach (var cow in GetList(CowLocationEnum.field))
        {
            SendAllToPosition(CowLocationEnum.field, LocationAI.Instance.GetPositionCow(0));
            cow.CurrentStage = CowAI.StageEnum.ToButcher;
            cow.ButcherDistanceCheck();
        }
    }

    private void ButcherCow()
    {
        if (_readyCows.Count <= 0)
        {
            GuardManager.Instance.TriggerGuards(GuardManager.LocationEnum.Butchery);
            return;
        }
        _readyCows[0].StoppingDistance = 0;
        _readyCows[0].CurrentStage = CowAI.StageEnum.Butcher;
        _readyCows[0].SendToLocation(LocationAI.Instance.Crusher.position);
    }

    public void FinishedButchering()
    {
        Destroy(_readyCows[0].gameObject);
        RemoveFromList(CowLocationEnum.field, _readyCows[0]);
        _readyCows.RemoveAt(0);
         Invoke("ButcherCow", 10);

    }

  

}
