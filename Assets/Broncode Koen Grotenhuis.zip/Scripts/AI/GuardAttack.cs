﻿using System.Collections;
using System.Collections.Generic;
using AI;
using UnityEngine;
using UnityEngine.AI;


public class GuardAttack : MonoBehaviour
{
    private LegMoveAI _legMoveAI;
    private IGuardBehaviour _enum;


    private GameObject LeftArm;
    private GameObject RightArm;

    private NavMeshAgent _navMeshAgent;

    private bool _onceLock;
    private bool _checkDistance;

    public float AttackDuration;
    public float RotationSpeed;
    private float _originalNavMeshSpeed;

    private bool _timerDone;
    private bool _stopRequest;

    private void Awake()
    {
        _legMoveAI = GetComponent<LegMoveAI>();
        _navMeshAgent = GetComponent<NavMeshAgent>();

        LeftArm = _legMoveAI.FrontLegs[1];
        RightArm = _legMoveAI.HindLegs[1];
        _originalNavMeshSpeed = _navMeshAgent.speed;
    }

    private void Update()
    {
        transform.LookAt(GameController.Instance.GetPlayerLocation.position);
        if (!_checkDistance || _onceLock) return;
       
        if (_navMeshAgent.remainingDistance < 3)
        {
           
            StartCoroutine(StartSpin());
            _onceLock = true;
        }
    }


    public void StateHasChanged(GuardManager.GuardState type)
    {
        if (type == GuardManager.GuardState.Triggerd)
        {
            _checkDistance = true;
        }
    }

    private IEnumerator StartSpin()
    {
        Quaternion temp1= LeftArm.transform.rotation;
        Quaternion temp2 = RightArm.transform.rotation;

        StartCoroutine(AttackTimer());
 
        _navMeshAgent.speed = _originalNavMeshSpeed * 2;
        while (!_timerDone)
        {
            LeftArm.transform.Rotate(RotationSpeed,0,0, Space.Self);
            RightArm.transform.Rotate(RotationSpeed, 0, 0, Space.Self);

            if (_stopRequest)
            {
                LeftArm.transform.rotation = temp1;
                RightArm.transform.rotation = temp2;
                _onceLock = false;
                _checkDistance = false;
                _stopRequest = false;
                StartCoroutine(SlowDownTimer());
                yield break;

            }

            yield return null;

        }
    }

    private IEnumerator AttackTimer()
    {
        yield return new WaitForSeconds(AttackDuration);
        _stopRequest = true;
    }

    private IEnumerator SlowDownTimer()
    {
        _navMeshAgent.speed = _originalNavMeshSpeed / 2;
        yield return  new WaitForSeconds(3);
        _navMeshAgent.speed = _originalNavMeshSpeed;

    }
}

