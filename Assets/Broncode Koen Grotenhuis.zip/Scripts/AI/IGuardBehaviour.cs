﻿using System.Collections;
using System.Collections.Generic;
using AI;
using UnityEngine;

public interface IGuardBehaviour
{
    GuardManager.GuardState GetEnum();
    float GetDamage();
}
