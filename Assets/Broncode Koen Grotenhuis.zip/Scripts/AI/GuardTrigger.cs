﻿using System.Collections;
using System.Collections.Generic;
using AI;
using UnityEngine;

public class GuardTrigger : MonoBehaviour   
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            
            GuardManager.Instance.TriggerGuards(GuardManager.LocationEnum.Gatehouse);
            CowManager.Instance.SendAllToPosition(CowManager.CowLocationEnum.field,LocationAI.Instance.GetPositionCow(2));

        }
    }
}
