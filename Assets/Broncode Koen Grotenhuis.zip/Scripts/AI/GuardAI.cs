﻿using System;
using Items;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

namespace AI
{
    public class GuardAI : _AI , IGuardBehaviour
    {
        

        private int _currentIndex;
        private const float MaxDistance = 1.5f;


        private float _health = 1;
        public float Health
        {
            get { return _health; }
            set
            {             
                _health = value;
                HealthSlider.value = _health;
                if (_health <= 0)
                {
                    InventoryManager.Instance.InstansiateAccessItem(transform);
                    Destroy(gameObject);
                }
            }
        }
        public Slider HealthSlider;



        public GuardManager.LocationEnum Location;

   


        private GuardAttack _guardAttack;
        public GuardManager.GuardState GuardState;
     

    
        //Interface
        public GuardManager.GuardState GetEnum()
        {
            return GuardState;
        }

        protected override void Awake()
        {
            _guardAttack = GetComponent<GuardAttack>();
            base.Awake();
        }
        


        private const float Damage = 0.05f;
        public float GetDamage()
        {
            return Damage;
        }



        private void Start()
        {
            GuardManager.Instance.Add(Location, this);
  
            GuardState = GuardManager.GuardState.Chill;
        }

        public void SetLocationEnum(GuardManager.LocationEnum type)
        {
            Location = type;
        }

        private void InitFence()
        {
            var tempLoc = LocationAI.Instance.GetClosestPositionFence(transform.position);
            _currentIndex = LocationAI.Instance.GetFenceVector3Index(tempLoc);
            NavMeshAgent.SetDestination(tempLoc);
        }

        

        public void SetState(GuardManager.GuardState state)
        {
            GuardState = state;
            if (GuardState == GuardManager.GuardState.Triggerd)
            {
                SendToLocation(GameController.Instance.GetPlayerLocation, true);
                _guardAttack.StateHasChanged(state);
                
            }
        }

  
    }
}
