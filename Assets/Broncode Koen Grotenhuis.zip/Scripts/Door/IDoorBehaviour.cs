﻿namespace Door
{
    public interface IDoorBehaviour
    {
        void Open();
        void Close();
        int ID();
    }
}
