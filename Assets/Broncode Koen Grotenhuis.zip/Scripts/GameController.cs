﻿using System.Collections;
using System.Collections.Generic;
using Player;
using Tools;
using UnityEngine;

public class GameController : Singleton<GameController>
{
    [HideInInspector] public PlayerController Player;

    protected override void Awake()
    {
        Player = GameObject.FindWithTag("Player").GetComponent<PlayerController>();
        base.Awake();
    }

    public Transform GetPlayerLocation => Player.transform;
}
