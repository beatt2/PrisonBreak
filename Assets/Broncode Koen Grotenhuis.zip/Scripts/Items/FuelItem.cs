﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FuelItem : Item
{
    public float FuelValue;

    public FuelItem(string name, int weight, float fuelValue) : base(name, weight)
    {
        FuelValue = fuelValue;
    }
}
