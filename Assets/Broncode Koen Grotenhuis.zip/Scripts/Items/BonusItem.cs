﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BonusItem : Item
{
    private readonly int _value;

    public int Value
    {
        get { return _value; }
    }

    public BonusItem(string name, int weight, int value) : base(name, weight)
    {
        _value = value;
    }
}
