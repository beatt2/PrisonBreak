﻿using System;
using System.Collections;
using System.Collections.Generic;
using AI;
using Items;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AI;

public class DynamiteItem : Item
{
    private readonly float _timeTillExplosion;
    public float TimeTillExplosion => _timeTillExplosion;

    private Collider _other;
    private DynamiteVisual _dynamiteVisual;

    public enum WhereAmIEnum
    {
        Player, Cow, Ground
    }

    public WhereAmIEnum WhereAmÍ;


    public DynamiteItem(string name, int weight, float timeTillExplosion) : base(name, weight)
    {
        _timeTillExplosion = timeTillExplosion;
        WhereAmÍ = WhereAmIEnum.Player;
    }


 

    private void StartTimer()
    {
        InventoryManager.Instance.StartTimer(TimeTillExplosion);
    }

    public void TimerFinished()
    {
        if (WhereAmÍ == WhereAmIEnum.Player)
        {
            //Player dies
        }

        if (WhereAmÍ != WhereAmIEnum.Cow) return;
        _dynamiteVisual.gameObject.GetComponent<CowAI>().ChangeNavMesh();
        //InventoryManager.Instance.RemoveItem(this);
    }

    public void TransferToOtherCow(GameObject cow)
    {
        _dynamiteVisual.Disable();
        _dynamiteVisual = cow.GetComponent<DynamiteVisual>();
        WhereAmÍ = WhereAmIEnum.Cow;
        CowManager.Instance.RemoveCow(cow);
        _dynamiteVisual.Enable();

    }

    public void StartTimerIfValid(Collider other)
    {
        if (other.gameObject.GetComponent<DynamiteVisual>() != null)
        {
            _dynamiteVisual = other.gameObject.GetComponent<DynamiteVisual>();
            _dynamiteVisual.Enable();
            StartTimer();
        }
        else
        {

           throw new NullReferenceException();
        }
  
    }


}
