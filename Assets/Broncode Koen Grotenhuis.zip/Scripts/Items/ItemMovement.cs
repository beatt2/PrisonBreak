﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemMovement : MonoBehaviour
{
    private const float Speed = 0.002f;
    private const float Height = 0.008f;

    private Vector3 _targetOne;
    private Vector3 _targetTwo;

    // Use this for initialization
    private void Start()
    {
        StartCoroutine(UpDown());
    }


    private IEnumerator UpDown()
    {
        float f = 0;
        bool moving = true;
        _targetOne = new Vector3(transform.position.x, transform.position.y + Height, transform.position.z);
        _targetTwo = new Vector3(transform.position.x, transform.position.y - Height, transform.position.z);

        while (moving)
        {
            while (f < 1)
            {
                f += Time.deltaTime * Speed;
                transform.position = Vector3.Lerp(_targetOne, _targetTwo, f);
                transform.Rotate(0, Speed, 0);
                yield return null;
            }

            while (f > 0)
            {
                f -= Time.deltaTime * Speed;
                transform.position = Vector3.Lerp(_targetOne, _targetTwo, f);
                transform.Rotate(0, Speed, 0);
                yield return null;
            }

           
            yield return null;
        }
    }
}