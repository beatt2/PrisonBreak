﻿using System.Collections;
using System.Collections.Generic;
using Items;
using UnityEngine;

public class ItemPickUp : MonoBehaviour
{
    public int Weight;
    public string Name;

    
    protected  virtual void Trigger(Item myItem)
    {
        InventoryManager.Instance.AddItem(myItem);
        Destroy(gameObject);
    }
    
}
