﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ReversedFallOfMap  
{

    public static float[,] GenerateReversedFallOfMap(int size, Vector2Int target)
    {

        float [,] values = new float[size,size];
        float maxValue = float.MinValue;
        Vector2Int coords = new Vector2Int();
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
            
                values[i, j] = Vector2Int.Distance(new Vector2Int(i, j), target);

            }
        }


        return values;
    }

    private static float Evaluate(float value)
    {
        const float a = -3;
        const float b = 0.2f;
        return Mathf.Pow(value, a) / (Mathf.Pow(value, a) + Mathf.Pow(b - b * value, a));
    }
}

